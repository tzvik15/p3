import React from 'react';
import "./chat.css"

function Chat (props) {
   return (
      <div className="chatbox">
         <ul id="messages"></ul>
        
    <form >
      <input id="m" autoComplete="off" /><button onClick={props.handleChatSend}>Send</button>
    </form>
      </div>
   )
}

export default Chat;