import React from 'react';
import './board.css'

function Board () {
   return (

      <div className="boardContainer">
         <div className="row">
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>    
         </div>

         <div className="row">
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>    
         </div>

         <div className="row">
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>    
         </div>

         <div className="row">
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>    
         </div>

         <div className="row">
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>
            <div className="col tile">
               *
            </div>    
         </div>

   </div>

   )
}

export default Board;