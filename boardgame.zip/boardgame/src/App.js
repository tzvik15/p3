import React, {useState, useEffect} from 'react';
import './App.css';
import Board from './components/Board/Board';
import TileCard from './components/TileCard/TileCard';
import Chat from './components/Chat/Chat';
import Choice from './components/Choice/Choice';
import Header from './components/Header/Header';
import io from "socket.io-client";
const socket = io("http://localhost");
// import { connect } from 'react-redux';
// import {
//    getCurrentPot,
//    sendNameToServer,
//    sendPitchInToServer,
//    sendGetOneToServer
//  } from './socket';



function App() {
   const [textValue, setTextValue] = useState('');
   // const io = require('socket.io')
   // let socket = io();
   // $(function () {
   //    var socket = io();
   //    $('form').submit(function(e){
   //      e.preventDefault(); // prevents page reloading
   //      socket.emit('chat message', $('#m').val());
   //      $('#m').val('');
   //      return false;
   //    });
   //    socket.on('chat message', function(msg){
   //      $('#messages').append($('<li>').text(msg));
   //    });
   //  });
  
    function handleChatSend(event) {
       event.preventDefault();
       setTextValue(event.target.value);
         socket.emit('chat message' + textValue)
      //  return false;
      };
      
      // socket.on('chat message', function(msg){
      //   alert(msg);
      // });
    
      useEffect(() => {
         socket.on('chat message', msg => {
           // update textarea with the msg
           setTextValue(msg);
         })
       }, [])
       



   return (
      <body>
         <textarea>
    {setTextValue}
  </textarea>
         <Header />

         <div className="content-container">
               
               <Board />
            
            <div className="cards-container col">

               <Chat 
                handleChatSend={handleChatSend}
               />
               <TileCard />
               <Choice />
               
            </div>

         </div>
         
      </body>
   )

   }
export default App;
