const app = require('express')();
// const express = require("express");
const path = require("path");
const https = require("https").createServer(app);
//const io = require("socket.io")(http, { origins: '*:*'});
const socket = require('socket.io-client')('https://localhost', { origins: '*:*'});
const PORT = process.env.PORT || 3001;

// app.use(express.urlencoded({ extended: true }));
// app.use(express.json());

// if(process.env.NODE_ENV === "production") {
//    app.use(express.static("client/build"));
// }

app.get("*", (req, res) => {
   res.sendFile(path.join(__dirname, "./client/build/index.html"));
});

// socket.on('connect', function(){});
// socket.on('event', function(data){});
// socket.on('disconnect', function(){});

socket.on('connection', function(socket){
   console.log('a user connected');
   socket.on('chat message', function(msg){
     console.log('message: ' + msg);
     socket.emit('chat message', msg);
   });
   socket.on('disconnect', function(){
     console.log('user disconnected');
   });
 });

// app.listen(PORT, () => {
//    console.log(`🌎 ==> API server now on port ${PORT}!`);
// });

https.listen(PORT, function(){
   console.log('listening on *:3001');
 });